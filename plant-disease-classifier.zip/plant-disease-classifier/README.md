# Plant Disease Classifier

A command-line computer vision project that classifies plant leaf images
as healthy or diseased (and by which disease) using transfer learning on
a pretrained convolutional neural network.

This project was built as a flipped-course project applying computer
vision concepts: image preprocessing, convolutional neural networks,
transfer learning, and model evaluation.

## Overview

Given a folder of labelled leaf images, the project:

1. Loads and preprocesses the images (resize, augmentation, normalization)
2. Fine-tunes a pretrained CNN backbone (ResNet18 / ResNet34 / MobileNetV2)
   on the new classes
3. Evaluates the trained model on a held-out test set (accuracy,
   precision, recall, F1, confusion matrix)
4. Predicts the class of new, unseen images from the command line

Everything runs from the terminal — there is no GUI.

## Features

- **Data pipeline**: automatic train/val/test loading via a standard
  folder layout, with augmentation on the training split only
- **Transfer learning**: choice of three pretrained backbones, with an
  option to freeze the backbone (fast, good for small datasets) or
  fine-tune it fully
- **Training loop**: early stopping, best-checkpoint saving, per-epoch
  logging to console and file
- **Evaluation**: accuracy, per-class precision/recall/F1, macro-averaged
  metrics, and a confusion matrix image, all written to `outputs/reports/`
- **Inference**: predict on a single image or an entire folder, with
  per-class confidence scores
- **Tests**: unit tests for the config, data loading, and model modules

## Technologies Used

| Purpose | Tool |
|---|---|
| Language | Python 3.10+ |
| Deep learning | PyTorch, torchvision |
| Image handling | Pillow |
| Metrics | scikit-learn |
| Plotting | Matplotlib |
| Testing | pytest |

## Project Structure

```
plant-disease-classifier/
├── main.py                  # CLI entry point (train / evaluate / predict)
├── requirements.txt
├── statement.md             # Problem statement, scope, target users
├── src/
│   ├── config.py            # Central configuration
│   ├── data_loader.py       # Dataset loading & preprocessing
│   ├── model.py             # Transfer-learning model definition
│   ├── train.py             # Training loop
│   ├── evaluate.py          # Test-set evaluation & metrics
│   ├── predict.py           # Inference on new images
│   └── utils.py             # Logging, seeding, checkpoint helpers
├── tests/                   # Unit tests (pytest)
├── docs/
│   ├── diagrams.md          # Mermaid source for all design diagrams
│   └── diagram_images/      # Rendered PNG versions of each diagram
└── outputs/
    ├── models/               # Saved checkpoints (best_model.pt)
    ├── logs/                 # Training logs & history
    └── reports/              # Evaluation metrics & confusion matrix
```

## Setup

### 1. Prerequisites

- Python 3.10 or later
- ~2 GB free disk space for dependencies (PyTorch is large)
- A CPU is sufficient for a small dataset; a GPU (CUDA) will train faster
  and is used automatically if available

### 2. Clone the repository

```bash
git clone https://github.com/<your-username>/plant-disease-classifier.git
cd plant-disease-classifier
```

### 3. Create a virtual environment (recommended)

```bash
python3 -m venv venv
source venv/bin/activate        # on Windows: venv\Scripts\activate
```

### 4. Install dependencies

```bash
pip install -r requirements.txt
```

### 5. Get a dataset

This project expects any labelled leaf-image dataset arranged as:

```
data/
├── train/
│   ├── <class_name_1>/*.jpg
│   ├── <class_name_2>/*.jpg
│   └── ...
├── val/
│   ├── <class_name_1>/*.jpg
│   └── ...
└── test/
    ├── <class_name_1>/*.jpg
    └── ...
```

A good public source is the **PlantVillage** dataset (available on
Kaggle — search "PlantVillage Dataset"). After downloading:

1. Place the extracted class folders under `data/`.
2. Split each class into `train/`, `val/`, and `test/` subfolders (a
   common split is 70% / 15% / 15%). You can do this manually, or write a
   small script using `sklearn.model_selection.train_test_split` — this
   step is intentionally left to you as it is dataset-specific.

You do **not** need the full dataset to test that the project runs — a
small subset (e.g. 3 classes, 30–50 images each) is enough to verify the
pipeline end to end before a full training run.

## Running the Project

All commands are run from the repository root.

### Train the model

```bash
python main.py train --data-dir data --backbone resnet18 --epochs 15
```

Useful flags:
- `--backbone {resnet18,resnet34,mobilenet_v2}` — choose the pretrained backbone
- `--epochs N` — number of training epochs (default 15)
- `--batch-size N` — batch size (default 32)
- `--lr 0.001` — learning rate
- `--no-freeze` — fine-tune the whole backbone instead of only the head
- `--device {auto,cpu,cuda}` — force a device (default: auto-detect)

The best checkpoint (by validation loss) is saved to
`outputs/models/best_model.pt`. Training logs are written to
`outputs/logs/train.log` and `outputs/logs/training_history.json`.

### Evaluate on the test set

```bash
python main.py evaluate --data-dir data --backbone resnet18
```

Writes `outputs/reports/evaluation_results.json` (accuracy, per-class and
macro precision/recall/F1, raw confusion matrix) and
`outputs/reports/confusion_matrix.png`.

### Predict on a new image

```bash
python main.py predict --image path/to/leaf.jpg --backbone resnet18
```

Or predict on every image in a folder at once:

```bash
python main.py predict --image path/to/folder_of_images/
```

Prints a JSON result with the predicted class and per-class confidence
scores for each image.

### Help for any command

```bash
python main.py train --help
python main.py evaluate --help
python main.py predict --help
```

## Testing

Run the unit test suite with:

```bash
python -m pytest tests/ -v
```

Tests for `data_loader.py` and `model.py` are automatically skipped if
`torch`/`torchvision` are not installed in the current environment, so
`tests/test_utils.py` can be run even in a minimal environment as a quick
sanity check.

## Non-Functional Requirements Addressed

| Requirement | How it's addressed |
|---|---|
| **Performance** | Backbone freezing option trains fast on CPU; auto GPU detection when available |
| **Reliability** | Early stopping, best-checkpoint-only saving, explicit error messages for missing/mismatched data |
| **Usability** | Single CLI entry point with `--help` on every command; clear README with copy-pasteable commands |
| **Maintainability** | All configuration centralized in `config.py`; modular single-responsibility files |
| **Logging & Monitoring** | Per-epoch console + file logging; training history and evaluation results saved as JSON |

See the project report (`docs/Project_Report.pdf`) for full details,
diagrams, and evaluation results.

## Notes

- This repository ships **code and structure only** — no trained model
  weights or dataset are included (see `.gitignore`), since datasets and
  model checkpoints do not belong in version control.
- Before submitting, run a real training + evaluation pass on your chosen
  dataset and update the report's results section with your actual
  metrics and screenshots.
