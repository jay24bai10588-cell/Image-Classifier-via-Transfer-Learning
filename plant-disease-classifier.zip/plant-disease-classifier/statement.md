# Problem Statement

## Problem Statement

Farmers and home gardeners often struggle to identify plant diseases
early, since visual symptoms on leaves (spots, discoloration, blight
patterns) can be subtle and easy to confuse between diseases. Delayed or
incorrect identification leads to delayed treatment, overuse of
pesticides, and avoidable crop loss. A lightweight, automated tool that
can classify a photographed leaf as healthy or diseased — and identify
the likely disease — can help non-experts get a fast, first-pass
diagnosis before consulting an agricultural expert.

## Scope

This project covers:

- Preprocessing a labelled dataset of leaf images into a form usable for
  training a convolutional neural network
- Fine-tuning a pretrained image classification backbone (transfer
  learning) on the target classes
- Evaluating classification performance on a held-out test set using
  standard metrics (accuracy, precision, recall, F1, confusion matrix)
- Providing a command-line tool to classify new leaf images and report a
  confidence score

Out of scope for this project:

- Mobile or web front-end deployment
- Real-time video/camera-feed classification
- Disease treatment recommendations (the project identifies the disease;
  it does not advise on treatment)
- Multi-plant, multi-organ (stem/fruit) disease detection — the scope is
  limited to leaf images

## Target Users

- Students and hobbyist gardeners wanting a quick, informal diagnosis
- Agricultural extension workers doing a first-pass triage across many
  samples before deeper investigation
- Anyone learning applied computer vision who wants a concrete,
  end-to-end classification pipeline to study or extend

## High-Level Features

1. **Data ingestion & preprocessing** — load a folder-structured image
   dataset, resize/augment/normalize images for training
2. **Model training** — fine-tune a pretrained CNN (ResNet18/34 or
   MobileNetV2) on the target disease classes, with early stopping and
   checkpointing
3. **Evaluation** — compute accuracy, per-class and macro precision /
   recall / F1, and a confusion matrix on a held-out test set
4. **Inference** — classify a new image (or batch of images) from the
   command line and report the predicted class with a confidence score
5. **Logging & reproducibility** — consistent logging across all stages,
   fixed random seeding, and versioned checkpoints tied to their class
   mapping
