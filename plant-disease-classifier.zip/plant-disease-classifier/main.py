#!/usr/bin/env python3
"""
main.py
-------
Single command-line entry point for the whole project, satisfying the
"must be fully executable via the command line" requirement. Every
functional module (data loading, training, evaluation, inference) is
reachable from here -- there is no GUI and none is required.

Usage
-----
    python main.py train    [--data-dir data] [--backbone resnet18] [--epochs 15] ...
    python main.py evaluate [--data-dir data] [--backbone resnet18]
    python main.py predict  --image path/to/image_or_folder [--backbone resnet18]

Run `python main.py <command> --help` for the full list of flags for that
command.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from src.config import Config


def build_config_from_args(args: argparse.Namespace) -> Config:
    cfg = Config()
    if getattr(args, "data_dir", None):
        cfg.data_dir = Path(args.data_dir)
    if getattr(args, "output_dir", None):
        cfg.output_dir = Path(args.output_dir)
    if getattr(args, "backbone", None):
        cfg.backbone = args.backbone
    if getattr(args, "epochs", None):
        cfg.epochs = args.epochs
    if getattr(args, "batch_size", None):
        cfg.batch_size = args.batch_size
    if getattr(args, "lr", None):
        cfg.learning_rate = args.lr
    if getattr(args, "device", None):
        cfg.device = args.device
    if getattr(args, "no_freeze", False):
        cfg.freeze_backbone = False
    cfg.__post_init__()
    return cfg


def cmd_train(args: argparse.Namespace) -> int:
    from src.train import train_model

    cfg = build_config_from_args(args)
    train_model(cfg)
    return 0


def cmd_evaluate(args: argparse.Namespace) -> int:
    from src.evaluate import evaluate_model

    cfg = build_config_from_args(args)
    results = evaluate_model(cfg)
    print(json.dumps({k: v for k, v in results.items() if k != "confusion_matrix"}, indent=2))
    return 0


def cmd_predict(args: argparse.Namespace) -> int:
    from src.predict import predict_path

    cfg = build_config_from_args(args)
    results = predict_path(cfg, Path(args.image))
    print(json.dumps(results, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="main.py",
        description="Plant Disease Classifier -- computer vision project CLI",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--data-dir", default="data", help="Path to dataset root (default: data)")
    common.add_argument("--output-dir", default="outputs", help="Path to write models/logs/reports")
    common.add_argument("--backbone", default="resnet18",
                         choices=["resnet18", "resnet34", "mobilenet_v2"])
    common.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])

    p_train = subparsers.add_parser("train", parents=[common], help="Train the model")
    p_train.add_argument("--epochs", type=int, default=15)
    p_train.add_argument("--batch-size", type=int, default=32)
    p_train.add_argument("--lr", type=float, default=1e-3)
    p_train.add_argument("--no-freeze", action="store_true",
                          help="Fine-tune the whole backbone instead of freezing it")
    p_train.set_defaults(func=cmd_train)

    p_eval = subparsers.add_parser("evaluate", parents=[common], help="Evaluate on the test split")
    p_eval.set_defaults(func=cmd_evaluate)

    p_predict = subparsers.add_parser("predict", parents=[common], help="Predict on a new image or folder")
    p_predict.add_argument("--image", required=True, help="Path to an image file or a folder of images")
    p_predict.set_defaults(func=cmd_predict)

    return parser


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
