"""
Unit tests for src/utils.py and src/config.py.

Run with:  python -m pytest tests/ -v
"""

import json
from pathlib import Path

import pytest

from src.config import Config
from src.utils import read_json, set_seed, write_json


def test_config_derives_output_subdirs(tmp_path):
    cfg = Config(output_dir=tmp_path / "outputs")
    assert cfg.model_dir == tmp_path / "outputs" / "models"
    assert cfg.log_dir == tmp_path / "outputs" / "logs"
    assert cfg.report_dir == tmp_path / "outputs" / "reports"


def test_config_ensure_dirs_creates_folders(tmp_path):
    cfg = Config(output_dir=tmp_path / "outputs")
    cfg.ensure_dirs()
    assert cfg.model_dir.exists()
    assert cfg.log_dir.exists()
    assert cfg.report_dir.exists()


def test_set_seed_is_deterministic():
    import random

    set_seed(123)
    first = [random.random() for _ in range(5)]
    set_seed(123)
    second = [random.random() for _ in range(5)]
    assert first == second


def test_write_and_read_json_round_trip(tmp_path):
    data = {"accuracy": 0.93, "classes": ["healthy", "blighted"]}
    path = tmp_path / "nested" / "results.json"
    write_json(data, path)

    assert path.exists()
    loaded = read_json(path)
    assert loaded == data


def test_read_json_missing_file_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        read_json(tmp_path / "does_not_exist.json")
