"""
Unit tests for src/model.py.

Skipped automatically if torch/torchvision are not installed in the
current environment (e.g. a lightweight CI check).

Run with:  python -m pytest tests/ -v
"""

import pytest

torch = pytest.importorskip("torch", reason="torch not installed in this environment")


def test_build_model_rejects_unknown_backbone():
    from src.model import build_model

    with pytest.raises(ValueError):
        build_model("not_a_real_backbone", num_classes=5)


def test_build_model_output_shape_matches_num_classes():
    from src.model import build_model

    num_classes = 7
    model = build_model("resnet18", num_classes=num_classes, pretrained=False, freeze_backbone=False)
    dummy_input = torch.randn(2, 3, 224, 224)
    output = model(dummy_input)
    assert output.shape == (2, num_classes)


def test_freeze_backbone_leaves_head_trainable():
    from src.model import build_model, count_trainable_params

    model = build_model("resnet18", num_classes=3, pretrained=False, freeze_backbone=True)
    trainable = count_trainable_params(model)
    # Only the replaced Linear head should be trainable: weight + bias.
    head_params = sum(p.numel() for p in model.fc.parameters())
    assert trainable == head_params
