"""
Unit tests for src/data_loader.py.

These focus on the parts that don't require torch/torchvision to be
installed (path validation, error messages), plus the transform pipeline
and full loader construction, which are skipped automatically if torch is
not available in the current environment.

Run with:  python -m pytest tests/ -v
"""

from pathlib import Path

import pytest

from src.config import Config
from src.data_loader import _check_split_exists

torch = pytest.importorskip("torch", reason="torch not installed in this environment")


def test_check_split_exists_raises_helpful_error(tmp_path):
    with pytest.raises(FileNotFoundError, match="train"):
        _check_split_exists(tmp_path, "train")


def test_check_split_exists_returns_path_when_present(tmp_path):
    split_dir = tmp_path / "train"
    split_dir.mkdir()
    result = _check_split_exists(tmp_path, "train")
    assert result == split_dir


def test_build_transforms_train_vs_eval_differ():
    from src.data_loader import build_transforms

    train_t = build_transforms(224, train=True)
    eval_t = build_transforms(224, train=False)
    # Training pipeline should include more augmentation steps than eval.
    assert len(train_t.transforms) > len(eval_t.transforms)


def test_get_dataloaders_missing_data_dir_raises(tmp_path):
    cfg = Config(data_dir=tmp_path / "nonexistent")
    with pytest.raises(FileNotFoundError):
        from src.data_loader import get_dataloaders

        get_dataloaders(cfg)
