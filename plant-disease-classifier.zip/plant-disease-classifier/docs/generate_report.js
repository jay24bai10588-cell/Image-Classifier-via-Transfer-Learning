const fs = require("fs");
const path = require("path");
const sizeOf = (p) => {
  // minimal PNG size reader (avoids extra deps)
  const buf = fs.readFileSync(p);
  const width = buf.readUInt32BE(16);
  const height = buf.readUInt32BE(20);
  return { width, height };
};

const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, ImageRun,
  Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle,
  AlignmentType, PageBreak, LevelFormat, Numbering
} = require("docx");

const IMG_DIR = path.join(__dirname, "diagram_images");

function scaledImage(filename, maxWidthPx) {
  const p = path.join(IMG_DIR, filename);
  const { width, height } = sizeOf(p);
  const scale = Math.min(1, maxWidthPx / width);
  return new ImageRun({
    type: "png",
    data: fs.readFileSync(p),
    transformation: { width: Math.round(width * scale), height: Math.round(height * scale) },
  });
}

function h1(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_1, spacing: { before: 300, after: 150 } });
}
function h2(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_2, spacing: { before: 200, after: 100 } });
}
function body(text, opts = {}) {
  return new Paragraph({ children: [new TextRun({ text, ...opts })], spacing: { after: 120 } });
}
function bullet(text) {
  return new Paragraph({ text, bullet: { level: 0 }, spacing: { after: 60 } });
}
function todo(text) {
  return new Paragraph({
    children: [new TextRun({ text: `[TODO — personalize before submission] ${text}`, italics: true, color: "B45309" })],
    spacing: { after: 150 },
  });
}
function figureCaption(text) {
  return new Paragraph({
    children: [new TextRun({ text, italics: true, size: 20 })],
    alignment: AlignmentType.CENTER,
    spacing: { after: 240 },
  });
}
function centeredImage(imgRun) {
  return new Paragraph({ children: [imgRun], alignment: AlignmentType.CENTER, spacing: { after: 60 } });
}

function simpleTable(headerRow, rows) {
  const mkCell = (text, bold = false, shade = null) =>
    new TableCell({
      width: { size: 100 / headerRow.length, type: WidthType.PERCENTAGE },
      shading: shade ? { type: ShadingType.CLEAR, fill: shade } : undefined,
      children: [new Paragraph({ children: [new TextRun({ text, bold })] })],
    });

  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [
      new TableRow({ children: headerRow.map((t) => mkCell(t, true, "D9E2F3")) }),
      ...rows.map((r) => new TableRow({ children: r.map((t) => mkCell(t)) })),
    ],
  });
}

const doc = new Document({
  numbering: {
    config: [
      {
        reference: "default-bullets",
        levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT }],
      },
    ],
  },
  sections: [
    {
      properties: {},
      children: [
        // ---------------- Cover Page ----------------
        new Paragraph({ text: "", spacing: { before: 2000 } }),
        new Paragraph({
          children: [new TextRun({ text: "Plant Disease Classifier", bold: true, size: 56 })],
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
        }),
        new Paragraph({
          children: [new TextRun({ text: "A Computer Vision Project Using Transfer Learning", size: 30 })],
          alignment: AlignmentType.CENTER,
          spacing: { after: 800 },
        }),
        new Paragraph({
          children: [new TextRun({ text: "Project Report", size: 26, bold: true })],
          alignment: AlignmentType.CENTER,
          spacing: { after: 1200 },
        }),
        new Paragraph({
          children: [new TextRun({ text: "[Your Name]", size: 24 })],
          alignment: AlignmentType.CENTER, spacing: { after: 100 },
        }),
        new Paragraph({
          children: [new TextRun({ text: "[Your Roll / Registration Number]", size: 24 })],
          alignment: AlignmentType.CENTER, spacing: { after: 100 },
        }),
        new Paragraph({
          children: [new TextRun({ text: "[Course Name — Computer Vision]", size: 24 })],
          alignment: AlignmentType.CENTER, spacing: { after: 100 },
        }),
        new Paragraph({
          children: [new TextRun({ text: "[Submission Date]", size: 24 })],
          alignment: AlignmentType.CENTER, spacing: { after: 100 },
        }),
        new Paragraph({ children: [new PageBreak()] }),

        // ---------------- 2. Introduction ----------------
        h1("2. Introduction"),
        body(
          "Plant diseases are a major cause of crop loss worldwide, and early identification is one of " +
          "the most effective ways to limit their spread. Manual inspection by experts is accurate but does " +
          "not scale to the number of plants that need checking, especially for hobbyist growers or small " +
          "farms without easy access to an agronomist. This project explores how computer vision — " +
          "specifically transfer learning on convolutional neural networks (CNNs) — can be used to build a " +
          "practical, lightweight tool that classifies a photographed leaf as healthy or diseased, and " +
          "identifies the likely disease, entirely from the command line."
        ),
        body(
          "The project applies core computer vision and deep learning concepts covered in the course: " +
          "image preprocessing and augmentation, convolutional neural network architectures, transfer " +
          "learning, training/validation/test methodology, and standard classification evaluation metrics."
        ),

        // ---------------- 3. Problem Statement ----------------
        h1("3. Problem Statement"),
        body(
          "Farmers and home gardeners often struggle to identify plant diseases early, since visual " +
          "symptoms on leaves (spots, discoloration, blight patterns) can be subtle and easy to confuse " +
          "between diseases. Delayed or incorrect identification leads to delayed treatment, overuse of " +
          "pesticides, and avoidable crop loss. This project builds an automated tool that classifies a " +
          "photographed leaf image and reports the most likely condition with a confidence score, " +
          "providing a fast first-pass diagnosis before consulting an expert."
        ),
        h2("Scope"),
        bullet("In scope: dataset preprocessing, model training via transfer learning, evaluation on a held-out test set, command-line inference on new images."),
        bullet("Out of scope: mobile/web deployment, real-time video classification, treatment recommendations, non-leaf plant parts."),
        h2("Target Users"),
        bullet("Students and hobbyist gardeners seeking a quick, informal diagnosis."),
        bullet("Agricultural extension workers doing first-pass triage across many samples."),
        bullet("Learners studying applied computer vision who want an end-to-end reference pipeline."),

        // ---------------- 4. Functional Requirements ----------------
        h1("4. Functional Requirements"),
        body("The system is organized into five functional modules, each with a clear input/output contract:"),
        simpleTable(
          ["#", "Module", "Input", "Output"],
          [
            ["1", "Data ingestion & preprocessing (data_loader.py)", "Raw labelled image folders (train/val/test)", "Batched, normalized, augmented tensors"],
            ["2", "Model definition (model.py)", "Backbone name, number of classes", "A CNN with a new classification head"],
            ["3", "Training (train.py)", "Preprocessed data + model", "Trained checkpoint (best_model.pt) + training logs"],
            ["4", "Evaluation (evaluate.py)", "Trained checkpoint + test split", "Accuracy, precision/recall/F1, confusion matrix"],
            ["5", "Inference (predict.py)", "Trained checkpoint + a new image or folder", "Predicted class + confidence score(s)"],
          ]
        ),
        new Paragraph({ text: "", spacing: { after: 150 } }),
        body("The end-to-end workflow of how a user interacts with the system is: prepare dataset \u2192 train \u2192 evaluate \u2192 predict on new images, all driven through a single CLI entry point (main.py)."),

        // ---------------- 5. Non-Functional Requirements ----------------
        h1("5. Non-Functional Requirements"),
        simpleTable(
          ["Requirement", "How it is addressed"],
          [
            ["Performance", "Optional backbone-freezing trains quickly even on CPU; automatic GPU detection and use when available."],
            ["Reliability", "Early stopping and best-checkpoint-only saving prevent wasted computation and overfitting; explicit, descriptive errors for missing or mismatched data."],
            ["Usability", "A single CLI entry point (main.py) with --help on every subcommand; a README with copy-pasteable setup and run commands."],
            ["Maintainability", "All tunable values centralized in config.py; each module has a single, clearly documented responsibility."],
            ["Logging & Monitoring", "Consistent per-epoch logging to console and file; training history and evaluation metrics persisted as JSON for later inspection."],
          ]
        ),

        // ---------------- 6. System Architecture ----------------
        new Paragraph({ children: [new PageBreak()] }),
        h1("6. System Architecture"),
        body("The diagram below shows the major components of the system and how they interact: the CLI dispatches to one of three pipelines (train / evaluate / predict), all of which share the data layer, the model layer, and cross-cutting configuration/utility modules."),
        centeredImage(scaledImage("1_architecture.png", 520)),
        figureCaption("Figure 1: System Architecture"),

        // ---------------- 7. Design Diagrams ----------------
        h1("7. Design Diagrams"),
        h2("7.1 Process / Workflow Diagram"),
        centeredImage(scaledImage("2_workflow.png", 320)),
        figureCaption("Figure 2: Training and Evaluation Workflow"),

        h2("7.2 Use Case Diagram"),
        centeredImage(scaledImage("3_usecase.png", 420)),
        figureCaption("Figure 3: Use Case Diagram"),

        h2("7.3 Class / Component Diagram"),
        centeredImage(scaledImage("4_class.png", 520)),
        figureCaption("Figure 4: Class / Component Diagram"),

        h2("7.4 Sequence Diagram (Prediction Flow)"),
        centeredImage(scaledImage("5_sequence.png", 480)),
        figureCaption("Figure 5: Sequence Diagram — Predicting on a New Image"),

        h2("7.5 ER Diagram / Schema Design"),
        body("Not applicable. This project does not use a database; trained models are persisted as PyTorch checkpoint files (best_model.pt) containing the model's learned weights and the class-to-index label mapping together, so predictions can always be correctly decoded back to class names."),

        // ---------------- 8. Design Decisions & Rationale ----------------
        new Paragraph({ children: [new PageBreak()] }),
        h1("8. Design Decisions & Rationale"),
        h2("Transfer learning over training from scratch"),
        body("Training a CNN from scratch requires large amounts of labelled data and compute to reach good accuracy. Transfer learning starts from a backbone already trained on ImageNet, which has learned general-purpose visual features (edges, textures, shapes) that transfer well to leaf images, requiring far less data and time to reach a usable accuracy."),
        h2("Optional backbone freezing"),
        body("Freezing the backbone and training only the new classification head is fast and works well when the dataset is small, since it avoids overfitting a large number of parameters. The --no-freeze flag is provided so that, if the dataset is large enough, the whole network can be fine-tuned for potentially higher accuracy."),
        h2("Early stopping on validation loss"),
        body("Rather than training for a fixed number of epochs, the training loop monitors validation loss and stops once it has not improved for a set number of epochs. This avoids overfitting and unnecessary computation."),
        h2("Checkpoint + label mapping stored together"),
        body("A common bug in classification pipelines is a mismatch between a saved model and the label order it was trained with. Storing class_to_idx inside the same checkpoint file as the model weights makes that mismatch impossible."),
        h2("Single CLI entry point"),
        body("All functionality is reachable through main.py with subcommands (train / evaluate / predict), fulfilling the requirement that the project be fully executable from the command line and giving evaluators one predictable place to run the project from."),

        // ---------------- 9. Implementation Details ----------------
        h1("9. Implementation Details"),
        body("The project is implemented in Python using PyTorch and torchvision. Key implementation points:"),
        bullet("Data is loaded using torchvision's ImageFolder, which infers class labels from subfolder names."),
        bullet("Training-split images are augmented with random horizontal flips, small rotations, and colour jitter; validation/test images are only resized and normalized, so evaluation numbers reflect true generalization rather than being inflated by augmentation."),
        bullet("Normalization uses ImageNet's mean/std statistics, matching what the pretrained backbones expect."),
        bullet("Three interchangeable backbones are supported (ResNet18, ResNet34, MobileNetV2), selectable via a CLI flag, so different architectures can be compared without code changes."),
        bullet("All randomness (Python's random, NumPy, and PyTorch) is seeded for reproducible results."),
        bullet("Logging uses Python's built-in logging module, configured once in utils.py and reused everywhere so log format is consistent across training, evaluation, and prediction."),
        todo("Add any implementation details specific to the dataset and hyperparameters you actually used (e.g. dataset size, number of classes, final chosen backbone, training time)."),

        // ---------------- 10. Screenshots / Results ----------------
        h1("10. Screenshots / Results"),
        todo(
          "This section must be completed after you run real training and evaluation on your chosen " +
          "dataset. Include: (a) a terminal screenshot of `python main.py train ...` running with per-epoch " +
          "logs, (b) the final `python main.py evaluate ...` output showing accuracy/precision/recall/F1, " +
          "(c) the confusion_matrix.png generated in outputs/reports/, and (d) a screenshot of " +
          "`python main.py predict --image ...` correctly classifying a sample image. Do not submit this " +
          "report with placeholder results."
        ),

        // ---------------- 11. Testing Approach ----------------
        h1("11. Testing Approach"),
        body("The project includes a pytest-based test suite (tests/) covering:"),
        bullet("Configuration: derived output paths and directory creation (test_utils.py)."),
        bullet("Utilities: deterministic seeding, and JSON read/write round-tripping (test_utils.py)."),
        bullet("Data loading: helpful error messages for missing dataset splits, and that the training transform pipeline includes more augmentation steps than the evaluation pipeline (test_data_loader.py)."),
        bullet("Model: rejection of unknown backbone names, correct output shape matching the number of classes, and that backbone freezing leaves only the new head trainable (test_model.py)."),
        body("Tests that require torch/torchvision are automatically skipped if those packages are not installed, so the suite degrades gracefully in a minimal environment. Run the full suite with: python -m pytest tests/ -v"),
        todo("Add a screenshot of your test run (all tests passing) here."),

        // ---------------- 12. Challenges Faced ----------------
        h1("12. Challenges Faced"),
        todo(
          "Write this section yourself, in your own words, based on what you actually encountered while " +
          "getting your dataset, running training, and debugging. Example angles: dataset class imbalance, " +
          "choosing a learning rate, training time on your hardware, images that failed to load, or getting " +
          "the train/val/test split right. Generic or fabricated challenges are easy for both an evaluator " +
          "and an AI-content detector to spot — this section should reflect your real experience."
        ),

        // ---------------- 13. Learnings & Key Takeaways ----------------
        h1("13. Learnings & Key Takeaways"),
        todo(
          "Write this section yourself. Reflect on what you learned about transfer learning, CNNs, " +
          "evaluation metrics, or software engineering practices (modular design, CLI tools, testing) " +
          "through building this project."
        ),

        // ---------------- 14. Future Enhancements ----------------
        h1("14. Future Enhancements"),
        bullet("Support additional backbones (e.g. EfficientNet, Vision Transformers)."),
        bullet("Add a lightweight web or mobile front-end for non-technical users."),
        bullet("Extend to real-time classification from a live camera feed."),
        bullet("Add Grad-CAM visualizations to show which parts of the leaf influenced the prediction, improving interpretability."),
        bullet("Package the trained model as a REST API for integration into other applications."),

        // ---------------- 15. References ----------------
        h1("15. References"),
        bullet("He, K., Zhang, X., Ren, S., & Sun, J. (2016). Deep Residual Learning for Image Recognition. CVPR."),
        bullet("Sandler, M., et al. (2018). MobileNetV2: Inverted Residuals and Linear Bottlenecks. CVPR."),
        bullet("PyTorch documentation: https://pytorch.org/docs/stable/index.html"),
        bullet("torchvision documentation: https://pytorch.org/vision/stable/index.html"),
        bullet("scikit-learn documentation: https://scikit-learn.org/stable/"),
        todo("Add the citation for whichever public dataset you actually used (e.g. the PlantVillage dataset's original paper or Kaggle page)."),
      ],
    },
  ],
});

Packer.toBuffer(doc).then((buffer) => {
  fs.writeFileSync(path.join(__dirname, "..", "outputs", "reports", "Project_Report.docx"), buffer);
  console.log("Report written.");
});
