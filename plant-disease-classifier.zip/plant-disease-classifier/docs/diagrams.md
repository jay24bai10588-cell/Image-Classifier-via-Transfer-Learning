# Design Diagrams

These render natively on GitHub. The same diagrams (as static images) are
embedded in the project report PDF.

## 1. System Architecture

```mermaid
flowchart TB
    subgraph CLI["Command-Line Interface (main.py)"]
        T[train command]
        E[evaluate command]
        P[predict command]
    end

    subgraph Data["Data Layer"]
        D1[data_loader.py]
        D2[(Dataset: train/val/test)]
    end

    subgraph Core["Model Layer"]
        M1[model.py<br/>pretrained backbone + new head]
        M2[train.py<br/>training loop]
        M3[evaluate.py<br/>metrics + confusion matrix]
        M4[predict.py<br/>inference]
    end

    subgraph Storage["Persisted Artifacts"]
        S1[(outputs/models/best_model.pt)]
        S2[(outputs/logs/*.log, *.json)]
        S3[(outputs/reports/*.json, *.png)]
    end

    subgraph Support["Cross-Cutting"]
        U1[utils.py<br/>logging, seeding, checkpoints]
        U2[config.py<br/>central configuration]
    end

    T --> M2
    E --> M3
    P --> M4

    M2 --> D1
    M3 --> D1
    D1 --> D2

    M2 --> M1
    M3 --> M1
    M4 --> M1

    M2 --> S1
    M2 --> S2
    M3 --> S3
    M3 --> S1
    M4 --> S1

    M1 -.-> U2
    M2 -.-> U1
    M3 -.-> U1
    M4 -.-> U1
    D1 -.-> U2
```

## 2. Process / Workflow Diagram (Training + Evaluation)

```mermaid
flowchart LR
    A[Raw leaf images] --> B[Organize into<br/>train/val/test folders]
    B --> C[data_loader.py<br/>resize, augment, normalize]
    C --> D[model.py<br/>load pretrained backbone]
    D --> E[train.py<br/>fine-tune classifier head]
    E --> F{Val loss<br/>improved?}
    F -- yes --> G[Save checkpoint]
    F -- no --> H[Increment patience counter]
    G --> I{More epochs<br/>or patience left?}
    H --> I
    I -- yes --> C
    I -- no --> J[evaluate.py<br/>run on test split]
    J --> K[Metrics + confusion matrix<br/>written to outputs/reports]
    K --> L[predict.py<br/>run inference on new images]
```

## 3. Use Case Diagram

```mermaid
flowchart TB
    actor((Student / User))

    actor --> UC1[Prepare dataset]
    actor --> UC2[Train model]
    actor --> UC3[Evaluate model on test set]
    actor --> UC4[Predict class of a new image]
    actor --> UC5[Inspect logs and metrics]

    UC2 -.includes.-> UC6[Load data]
    UC2 -.includes.-> UC7[Save checkpoint]
    UC3 -.includes.-> UC6
    UC3 -.includes.-> UC8[Load checkpoint]
    UC4 -.includes.-> UC8
```

## 4. Class / Component Diagram

```mermaid
classDiagram
    class Config {
        +Path data_dir
        +Path output_dir
        +str backbone
        +int epochs
        +float learning_rate
        +ensure_dirs()
    }

    class DataLoaderModule {
        +build_transforms(image_size, train)
        +get_dataloaders(cfg)
        +load_single_image(path, image_size)
    }

    class ModelModule {
        +build_model(backbone, num_classes, pretrained, freeze_backbone)
        +count_trainable_params(model)
    }

    class TrainModule {
        +train_model(cfg) Path
        -_run_one_epoch(model, loader, ...)
    }

    class EvaluateModule {
        +evaluate_model(cfg) dict
        -_save_confusion_matrix_plot(cm, class_names, path)
    }

    class PredictModule {
        +predict_image(cfg, image_path) dict
        +predict_path(cfg, path) list
    }

    class Utils {
        +set_seed(seed)
        +get_logger(name, log_dir)
        +resolve_device(preference)
        +save_checkpoint(model, class_to_idx, path)
        +load_checkpoint(path)
    }

    TrainModule --> DataLoaderModule
    TrainModule --> ModelModule
    TrainModule --> Utils
    TrainModule --> Config

    EvaluateModule --> DataLoaderModule
    EvaluateModule --> ModelModule
    EvaluateModule --> Utils
    EvaluateModule --> Config

    PredictModule --> DataLoaderModule
    PredictModule --> ModelModule
    PredictModule --> Utils
    PredictModule --> Config
```

## 5. Sequence Diagram (Prediction Flow)

```mermaid
sequenceDiagram
    participant User
    participant CLI as main.py
    participant Predict as predict.py
    participant Utils as utils.py
    participant Model as model.py
    participant Data as data_loader.py

    User->>CLI: python main.py predict --image leaf.jpg
    CLI->>Predict: predict_path(cfg, image_path)
    Predict->>Utils: load_checkpoint(checkpoint_path)
    Utils-->>Predict: model_state_dict, class_to_idx
    Predict->>Model: build_model(backbone, num_classes)
    Model-->>Predict: model instance
    Predict->>Data: load_single_image(path, image_size)
    Data-->>Predict: preprocessed tensor
    Predict->>Model: model(tensor)
    Model-->>Predict: logits
    Predict->>Predict: softmax -> predicted class + confidence
    Predict-->>CLI: result dict
    CLI-->>User: prints JSON prediction
```
