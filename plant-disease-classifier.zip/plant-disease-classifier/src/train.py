"""
train.py
--------
Functional Module 2 (part B): Model training loop.

Trains the model built in model.py on the data from data_loader.py, with:
    * early stopping on validation loss (reliability -- avoids wasted
      compute and overfitting on small datasets)
    * checkpointing of the best model only (not every epoch, to save disk)
    * per-epoch logging of train/val loss and accuracy (logging /
      monitoring non-functional requirement)

Run via: python main.py train [--epochs N] [--backbone resnet18] ...
"""

from __future__ import annotations

import time
from pathlib import Path

from src.config import Config
from src.data_loader import get_dataloaders
from src.model import build_model, count_trainable_params
from src.utils import get_logger, resolve_device, save_checkpoint, set_seed, write_json


def _run_one_epoch(model, loader, criterion, optimizer, device, train: bool):
    import torch

    model.train() if train else model.eval()

    running_loss, running_correct, total = 0.0, 0, 0
    context = torch.enable_grad() if train else torch.no_grad()

    with context:
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)

            if train:
                optimizer.zero_grad()

            outputs = model(images)
            loss = criterion(outputs, labels)

            if train:
                loss.backward()
                optimizer.step()

            running_loss += loss.item() * images.size(0)
            preds = outputs.argmax(dim=1)
            running_correct += (preds == labels).sum().item()
            total += images.size(0)

    return running_loss / total, running_correct / total


def train_model(cfg: Config) -> Path:
    """
    Full training run. Returns the path to the saved best checkpoint.
    """
    import torch
    import torch.nn as nn

    set_seed(cfg.seed)
    cfg.ensure_dirs()
    logger = get_logger("train", cfg.log_dir)

    device = resolve_device(cfg.device)
    logger.info(f"Using device: {device}")

    train_loader, val_loader, _test_loader, class_to_idx = get_dataloaders(cfg)
    logger.info(f"Found {len(class_to_idx)} classes: {list(class_to_idx.keys())}")

    model = build_model(cfg.backbone, len(class_to_idx), cfg.pretrained, cfg.freeze_backbone).to(device)
    logger.info(f"Trainable parameters: {count_trainable_params(model):,}")

    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(
        filter(lambda p: p.requires_grad, model.parameters()),
        lr=cfg.learning_rate,
        weight_decay=cfg.weight_decay,
    )

    best_val_loss = float("inf")
    epochs_without_improvement = 0
    checkpoint_path = cfg.model_dir / cfg.checkpoint_name
    history = []

    for epoch in range(1, cfg.epochs + 1):
        start = time.time()
        train_loss, train_acc = _run_one_epoch(model, train_loader, criterion, optimizer, device, train=True)
        val_loss, val_acc = _run_one_epoch(model, val_loader, criterion, optimizer, device, train=False)
        elapsed = time.time() - start

        logger.info(
            f"Epoch {epoch:02d}/{cfg.epochs} | "
            f"train_loss={train_loss:.4f} train_acc={train_acc:.4f} | "
            f"val_loss={val_loss:.4f} val_acc={val_acc:.4f} | "
            f"{elapsed:.1f}s"
        )
        history.append(
            {
                "epoch": epoch,
                "train_loss": train_loss,
                "train_acc": train_acc,
                "val_loss": val_loss,
                "val_acc": val_acc,
            }
        )

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            epochs_without_improvement = 0
            save_checkpoint(model, class_to_idx, checkpoint_path)
            logger.info(f"  -> new best model saved to {checkpoint_path}")
        else:
            epochs_without_improvement += 1
            if epochs_without_improvement >= cfg.early_stopping_patience:
                logger.info(
                    f"Early stopping: no val_loss improvement for "
                    f"{cfg.early_stopping_patience} epochs."
                )
                break

    write_json(history, cfg.log_dir / "training_history.json")
    logger.info(f"Training complete. Best val_loss={best_val_loss:.4f}. Checkpoint: {checkpoint_path}")
    return checkpoint_path
