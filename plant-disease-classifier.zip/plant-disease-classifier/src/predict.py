"""
predict.py
----------
Functional Module 4: Inference on new, unlabelled images.

Loads the trained checkpoint and predicts the class of one image (or every
image in a folder), printing the top prediction and confidence score. This
is the module an evaluator will actually exercise from the command line to
sanity-check that the project works end to end.

Run via:
    python main.py predict --image path/to/leaf.jpg
    python main.py predict --image path/to/folder_of_images/
"""

from __future__ import annotations

from pathlib import Path

from src.config import Config
from src.data_loader import load_single_image
from src.model import build_model
from src.utils import get_logger, load_checkpoint, resolve_device

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp"}


def _load_model_for_inference(cfg: Config):
    device = resolve_device(cfg.device)
    checkpoint_path = cfg.model_dir / cfg.checkpoint_name
    checkpoint = load_checkpoint(checkpoint_path, map_location=device)
    class_to_idx = checkpoint["class_to_idx"]
    idx_to_class = {v: k for k, v in class_to_idx.items()}

    model = build_model(cfg.backbone, len(class_to_idx), pretrained=False, freeze_backbone=False)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.to(device).eval()
    return model, idx_to_class, device


def predict_image(cfg: Config, image_path: Path) -> dict:
    """Predict the class of a single image. Returns a result dict."""
    import torch

    model, idx_to_class, device = _load_model_for_inference(cfg)
    tensor = load_single_image(image_path, cfg.image_size).to(device)

    with torch.no_grad():
        logits = model(tensor)
        probs = torch.softmax(logits, dim=1).squeeze(0)
        top_idx = int(torch.argmax(probs).item())

    return {
        "image": str(image_path),
        "predicted_class": idx_to_class[top_idx],
        "confidence": round(float(probs[top_idx]), 4),
        "all_probabilities": {
            idx_to_class[i]: round(float(p), 4) for i, p in enumerate(probs)
        },
    }


def predict_path(cfg: Config, path: Path) -> list[dict]:
    """
    Predict on a single image file, or every image in a folder.
    Returns a list of result dicts (length 1 for a single file).
    """
    logger = get_logger("predict", cfg.log_dir)
    path = Path(path)

    if not path.exists():
        raise FileNotFoundError(f"Path not found: {path}")

    if path.is_dir():
        image_paths = sorted(
            p for p in path.iterdir() if p.suffix.lower() in IMAGE_EXTENSIONS
        )
        if not image_paths:
            raise ValueError(f"No images with extensions {IMAGE_EXTENSIONS} found in {path}")
    else:
        image_paths = [path]

    results = []
    for img_path in image_paths:
        result = predict_image(cfg, img_path)
        logger.info(
            f"{result['image']} -> {result['predicted_class']} "
            f"(confidence={result['confidence']:.2%})"
        )
        results.append(result)

    return results
