"""
data_loader.py
---------------
Functional Module 1: Data ingestion & preprocessing.

Wraps torchvision's ImageFolder so the rest of the pipeline never has to
think about file paths, augmentation, or normalisation directly. Expects
the standard layout:

    data/
        train/<class_a>/*.jpg
        train/<class_b>/*.jpg
        val/<class_a>/*.jpg
        val/<class_b>/*.jpg
        test/<class_a>/*.jpg
        test/<class_b>/*.jpg

This is the layout produced by most public leaf-disease datasets (e.g.
PlantVillage) once split into train/val/test, and is also what
`torchvision.datasets.ImageFolder` expects natively.
"""

from __future__ import annotations

from pathlib import Path

from src.config import Config


# ImageNet mean/std -- correct normalisation to use whenever the backbone
# was pretrained on ImageNet (true for every backbone offered in model.py).
IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]


def build_transforms(image_size: int, train: bool):
    """
    Build the torchvision transform pipeline.

    Training gets light augmentation (flip + rotation + colour jitter) to
    reduce overfitting on small datasets; validation/test use only resize +
    normalise so evaluation numbers are not inflated or distorted by
    augmentation.
    """
    from torchvision import transforms

    if train:
        return transforms.Compose(
            [
                transforms.Resize((image_size, image_size)),
                transforms.RandomHorizontalFlip(),
                transforms.RandomRotation(15),
                transforms.ColorJitter(brightness=0.15, contrast=0.15, saturation=0.1),
                transforms.ToTensor(),
                transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
            ]
        )
    return transforms.Compose(
        [
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
        ]
    )


def _check_split_exists(data_dir: Path, split: str) -> Path:
    split_dir = data_dir / split
    if not split_dir.exists():
        raise FileNotFoundError(
            f"Expected a '{split}' folder at {split_dir}.\n"
            f"Your data directory must look like:\n"
            f"  {data_dir}/train/<class_name>/*.jpg\n"
            f"  {data_dir}/val/<class_name>/*.jpg\n"
            f"  {data_dir}/test/<class_name>/*.jpg\n"
            f"See README.md 'Dataset setup' for instructions."
        )
    return split_dir


def get_dataloaders(cfg: Config):
    """
    Build train/val/test DataLoaders plus the class_to_idx mapping.

    Returns
    -------
    (train_loader, val_loader, test_loader, class_to_idx)
    """
    import torch
    from torchvision.datasets import ImageFolder

    train_dir = _check_split_exists(cfg.data_dir, cfg.train_subdir)
    val_dir = _check_split_exists(cfg.data_dir, cfg.val_subdir)
    test_dir = _check_split_exists(cfg.data_dir, cfg.test_subdir)

    train_ds = ImageFolder(train_dir, transform=build_transforms(cfg.image_size, train=True))
    val_ds = ImageFolder(val_dir, transform=build_transforms(cfg.image_size, train=False))
    test_ds = ImageFolder(test_dir, transform=build_transforms(cfg.image_size, train=False))

    if train_ds.classes != val_ds.classes or train_ds.classes != test_ds.classes:
        raise ValueError(
            "Class folders differ between train/val/test splits. "
            "Every split must contain the exact same set of class subfolders."
        )

    train_loader = torch.utils.data.DataLoader(
        train_ds, batch_size=cfg.batch_size, shuffle=True, num_workers=cfg.num_workers
    )
    val_loader = torch.utils.data.DataLoader(
        val_ds, batch_size=cfg.batch_size, shuffle=False, num_workers=cfg.num_workers
    )
    test_loader = torch.utils.data.DataLoader(
        test_ds, batch_size=cfg.batch_size, shuffle=False, num_workers=cfg.num_workers
    )

    return train_loader, val_loader, test_loader, train_ds.class_to_idx


def load_single_image(image_path: Path, image_size: int):
    """Load and preprocess one image for inference (predict.py)."""
    from PIL import Image

    image_path = Path(image_path)
    if not image_path.exists():
        raise FileNotFoundError(f"Image not found: {image_path}")

    transform = build_transforms(image_size, train=False)
    image = Image.open(image_path).convert("RGB")
    tensor = transform(image)
    return tensor.unsqueeze(0)  # add batch dimension
