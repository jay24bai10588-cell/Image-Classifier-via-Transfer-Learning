"""
config.py
---------
Central configuration for the Plant Disease Classifier project.

Keeping all tunable values in one place satisfies the "maintainability"
non-functional requirement: nothing below needs to be hunted for inside
training/evaluation/inference code, and every module imports from here
instead of hard-coding values.
"""

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Config:
    # --- Paths -----------------------------------------------------------
    # Expected layout (standard torchvision ImageFolder format):
    #   data_dir/
    #       train/<class_name>/*.jpg
    #       val/<class_name>/*.jpg
    #       test/<class_name>/*.jpg
    data_dir: Path = Path("data")
    train_subdir: str = "train"
    val_subdir: str = "val"
    test_subdir: str = "test"

    output_dir: Path = Path("outputs")
    model_dir: Path = field(init=False)
    log_dir: Path = field(init=False)
    report_dir: Path = field(init=False)

    checkpoint_name: str = "best_model.pt"
    class_index_name: str = "class_index.json"

    # --- Data / preprocessing --------------------------------------------
    image_size: int = 224          # ResNet-family default input size
    batch_size: int = 32
    num_workers: int = 2

    # --- Model -------------------------------------------------------------
    backbone: str = "resnet18"     # one of: resnet18, resnet34, mobilenet_v2
    pretrained: bool = True
    freeze_backbone: bool = True   # if True, only the classifier head is trained

    # --- Training ------------------------------------------------------
    epochs: int = 15
    learning_rate: float = 1e-3
    weight_decay: float = 1e-4
    early_stopping_patience: int = 4
    seed: int = 42

    # --- Device ------------------------------------------------------------
    device: str = "auto"           # "auto" | "cpu" | "cuda"

    def __post_init__(self):
        self.data_dir = Path(self.data_dir)
        self.output_dir = Path(self.output_dir)
        self.model_dir = self.output_dir / "models"
        self.log_dir = self.output_dir / "logs"
        self.report_dir = self.output_dir / "reports"

    def ensure_dirs(self):
        """Create all output directories if they do not already exist."""
        for d in (self.model_dir, self.log_dir, self.report_dir):
            d.mkdir(parents=True, exist_ok=True)


DEFAULT_CONFIG = Config()
