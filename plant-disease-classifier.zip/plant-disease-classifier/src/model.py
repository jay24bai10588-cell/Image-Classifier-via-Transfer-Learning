"""
model.py
---------
Functional Module 2 (part A): Model definition via transfer learning.

Loads a pretrained CNN backbone (trained on ImageNet) and replaces its
final classification layer with one matching the number of classes in the
project's dataset. Optionally freezes the backbone so only the new head is
trained, which works well on small/medium datasets and keeps training fast
enough to run on a CPU.
"""

from __future__ import annotations


SUPPORTED_BACKBONES = ("resnet18", "resnet34", "mobilenet_v2")


def build_model(backbone: str, num_classes: int, pretrained: bool = True, freeze_backbone: bool = True):
    """
    Build a transfer-learning model.

    Parameters
    ----------
    backbone : one of SUPPORTED_BACKBONES
    num_classes : number of output classes, taken from the dataset
    pretrained : load ImageNet-pretrained weights
    freeze_backbone : if True, only the new classifier head has requires_grad=True

    Returns
    -------
    torch.nn.Module
    """
    import torch.nn as nn
    from torchvision import models

    if backbone not in SUPPORTED_BACKBONES:
        raise ValueError(f"Unknown backbone '{backbone}'. Choose from {SUPPORTED_BACKBONES}.")

    if backbone == "resnet18":
        weights = models.ResNet18_Weights.DEFAULT if pretrained else None
        net = models.resnet18(weights=weights)
        in_features = net.fc.in_features
        head_attr = "fc"
    elif backbone == "resnet34":
        weights = models.ResNet34_Weights.DEFAULT if pretrained else None
        net = models.resnet34(weights=weights)
        in_features = net.fc.in_features
        head_attr = "fc"
    else:  # mobilenet_v2
        weights = models.MobileNet_V2_Weights.DEFAULT if pretrained else None
        net = models.mobilenet_v2(weights=weights)
        in_features = net.classifier[-1].in_features
        head_attr = None  # handled separately below

    if freeze_backbone:
        for param in net.parameters():
            param.requires_grad = False

    # Replace the classification head. The new head's parameters always
    # have requires_grad=True regardless of freeze_backbone, since it must
    # always be trained from scratch for the new label set.
    new_head = nn.Linear(in_features, num_classes)

    if head_attr == "fc":
        net.fc = new_head
    else:
        net.classifier[-1] = new_head

    return net


def count_trainable_params(model) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)
