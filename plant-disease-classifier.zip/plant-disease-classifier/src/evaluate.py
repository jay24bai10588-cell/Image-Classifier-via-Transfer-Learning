"""
evaluate.py
-----------
Functional Module 3: Evaluation & reporting.

Loads the best checkpoint from training and reports accuracy, precision,
recall, F1 (per class and macro-averaged), plus a confusion matrix image,
on the held-out test split. These numbers -- not train accuracy -- are
what belongs in the project report's "Testing Approach" / "Results"
sections.

Run via: python main.py evaluate
"""

from __future__ import annotations

from pathlib import Path

from src.config import Config
from src.data_loader import get_dataloaders
from src.model import build_model
from src.utils import get_logger, load_checkpoint, resolve_device, write_json


def evaluate_model(cfg: Config) -> dict:
    import torch
    from sklearn.metrics import classification_report, confusion_matrix

    logger = get_logger("evaluate", cfg.log_dir)
    device = resolve_device(cfg.device)

    checkpoint_path = cfg.model_dir / cfg.checkpoint_name
    checkpoint = load_checkpoint(checkpoint_path, map_location=device)
    class_to_idx = checkpoint["class_to_idx"]
    idx_to_class = {v: k for k, v in class_to_idx.items()}

    _train_loader, _val_loader, test_loader, data_class_to_idx = get_dataloaders(cfg)
    if data_class_to_idx != class_to_idx:
        raise ValueError(
            "The class-to-index mapping in the checkpoint does not match the "
            "current dataset's classes. Re-train the model on this dataset first."
        )

    model = build_model(cfg.backbone, len(class_to_idx), pretrained=False, freeze_backbone=False)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.to(device).eval()

    all_preds, all_labels = [], []
    with torch.no_grad():
        for images, labels in test_loader:
            images = images.to(device)
            outputs = model(images)
            preds = outputs.argmax(dim=1).cpu().numpy()
            all_preds.extend(preds.tolist())
            all_labels.extend(labels.numpy().tolist())

    class_names = [idx_to_class[i] for i in range(len(idx_to_class))]
    report = classification_report(
        all_labels, all_preds, target_names=class_names, output_dict=True, zero_division=0
    )
    cm = confusion_matrix(all_labels, all_preds)

    logger.info(
        "Test accuracy: %.4f | macro F1: %.4f",
        report["accuracy"],
        report["macro avg"]["f1-score"],
    )

    results = {
        "accuracy": report["accuracy"],
        "macro_precision": report["macro avg"]["precision"],
        "macro_recall": report["macro avg"]["recall"],
        "macro_f1": report["macro avg"]["f1-score"],
        "per_class": {
            name: report[name] for name in class_names
        },
        "confusion_matrix": cm.tolist(),
        "class_order": class_names,
    }
    write_json(results, cfg.report_dir / "evaluation_results.json")

    _save_confusion_matrix_plot(cm, class_names, cfg.report_dir / "confusion_matrix.png")
    logger.info(f"Evaluation artifacts written to {cfg.report_dir}")

    return results


def _save_confusion_matrix_plot(cm, class_names, out_path: Path) -> None:
    """Save a confusion matrix heatmap for inclusion in the project report."""
    import matplotlib.pyplot as plt
    import numpy as np

    fig, ax = plt.subplots(figsize=(max(6, len(class_names) * 0.6), max(5, len(class_names) * 0.6)))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(np.arange(len(class_names)))
    ax.set_yticks(np.arange(len(class_names)))
    ax.set_xticklabels(class_names, rotation=45, ha="right")
    ax.set_yticklabels(class_names)
    ax.set_xlabel("Predicted label")
    ax.set_ylabel("True label")
    ax.set_title("Confusion Matrix (Test Set)")

    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, cm[i, j], ha="center", va="center",
                     color="white" if cm[i, j] > cm.max() / 2 else "black")

    fig.colorbar(im, ax=ax)
    fig.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
