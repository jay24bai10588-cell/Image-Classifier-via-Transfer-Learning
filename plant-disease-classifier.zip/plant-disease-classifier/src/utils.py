"""
utils.py
--------
Cross-cutting helpers shared by every other module:

    * reproducible seeding
    * consistent logging setup (console + rotating file handler)
    * device resolution ("auto" -> cuda if available, else cpu)
    * checkpoint save/load helpers

Centralising these here is what lets train.py, evaluate.py and predict.py
all behave consistently (same log format, same seed, same checkpoint
schema) without duplicating code -- directly supporting the
"maintainability" and "reliability" non-functional requirements.
"""

from __future__ import annotations

import json
import logging
import random
import sys
from pathlib import Path
from typing import Any

import numpy as np


def set_seed(seed: int) -> None:
    """Seed python, numpy and torch (if installed) for reproducible runs."""
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except ImportError:
        # torch may not be installed yet (e.g. during a lightweight test run)
        pass


def get_logger(name: str, log_dir: Path | None = None, level: int = logging.INFO) -> logging.Logger:
    """
    Return a logger that writes to stdout and, if log_dir is given, to
    outputs/logs/<name>.log as well. Safe to call repeatedly -- it will not
    attach duplicate handlers.
    """
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger

    logger.setLevel(level)
    fmt = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(fmt)
    logger.addHandler(stream_handler)

    if log_dir is not None:
        log_dir = Path(log_dir)
        log_dir.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_dir / f"{name}.log")
        file_handler.setFormatter(fmt)
        logger.addHandler(file_handler)

    return logger


def resolve_device(preference: str = "auto") -> str:
    """Resolve 'auto' | 'cpu' | 'cuda' to a concrete torch device string."""
    if preference != "auto":
        return preference
    try:
        import torch

        return "cuda" if torch.cuda.is_available() else "cpu"
    except ImportError:
        return "cpu"


def save_checkpoint(model, class_to_idx: dict, path: Path) -> None:
    """
    Save model weights plus the class-index mapping needed to interpret
    predictions later. Keeping both together prevents the classic bug of a
    model being evaluated/served with a mismatched label mapping.
    """
    import torch

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "model_state_dict": model.state_dict(),
            "class_to_idx": class_to_idx,
        },
        path,
    )


def load_checkpoint(path: Path, map_location: str = "cpu") -> dict:
    """Load a checkpoint dict written by save_checkpoint()."""
    import torch

    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Checkpoint not found at {path}. Did you run `python main.py train` first?"
        )
    return torch.load(path, map_location=map_location)


def write_json(data: Any, path: Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def read_json(path: Path) -> Any:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Expected file not found: {path}")
    with open(path) as f:
        return json.load(f)
